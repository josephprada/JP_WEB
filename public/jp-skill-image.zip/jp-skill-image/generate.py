#!/usr/bin/env python3
"""Generate an image with Cloudflare Workers AI (flux-1-schnell).

Standard library only — no pip install required.
"""
import argparse
import base64
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

MODEL = "@cf/black-forest-labs/flux-1-schnell"
SKILL_DIR = Path(__file__).resolve().parent


def parse_env_file(path):
    """Minimal .env parser: KEY=value, ignoring comments and blank lines."""
    values = {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[key] = value
    return values


def load_credentials():
    """Resolve credentials, in order of precedence:

    1. Real environment variables.
    2. A .env in the current directory or any parent (project-local override).
    3. The skill's own .env (global fallback, so the skill works anywhere).
    """
    sources = []
    cwd = Path.cwd().resolve()
    for directory in [cwd, *cwd.parents]:
        candidate = directory / ".env"
        if candidate.is_file():
            sources.append(candidate)
    skill_env = SKILL_DIR / ".env"
    if skill_env.is_file():
        sources.append(skill_env)

    resolved = {}
    for key in ("CF_ACCOUNT_ID", "CF_API_TOKEN"):
        value = os.getenv(key)
        if not value:
            for source in sources:
                value = parse_env_file(source).get(key)
                if value:
                    break
        resolved[key] = value
    return resolved["CF_ACCOUNT_ID"], resolved["CF_API_TOKEN"]


def generate_image(prompt, output_file="out.jpg", steps=4):
    account_id, api_token = load_credentials()

    if not account_id or not api_token:
        print(
            "Error: CF_ACCOUNT_ID and CF_API_TOKEN not found.\n"
            "Set them as environment variables, in a .env at your project root, "
            f"or in {SKILL_DIR / '.env'}",
            file=sys.stderr,
        )
        return False

    url = (
        f"https://api.cloudflare.com/client/v4/accounts/{account_id}"
        f"/ai/run/{MODEL}"
    )
    payload = json.dumps({"prompt": prompt, "steps": steps}).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    print(f"Generating image with prompt: {prompt}")
    print(f"Steps: {steps}")

    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            body = response.read()
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", "replace")
        print(f"Error: HTTP {error.code}\n{detail}", file=sys.stderr)
        return False
    except urllib.error.URLError as error:
        print(f"Error: request failed ({error.reason})", file=sys.stderr)
        return False

    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        print("Error: response was not valid JSON", file=sys.stderr)
        return False

    image_base64 = (data.get("result") or {}).get("image")
    if not image_base64:
        print(f"Error: no image data in response\n{data}", file=sys.stderr)
        return False

    output_path = Path(output_file)
    if str(output_path.parent) not in ("", "."):
        output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(base64.b64decode(image_base64))

    print(f"Saved {output_path.resolve()}")
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Generate an image using Cloudflare Workers AI Flux model"
    )
    parser.add_argument("prompt", help="Text description of the image to generate")
    parser.add_argument(
        "-o", "--output", default="out.jpg", help="Output file path (default: out.jpg)"
    )
    parser.add_argument(
        "--steps",
        type=int,
        default=4,
        help="Diffusion steps (default: 4, recommended: 4-8)",
    )
    args = parser.parse_args()
    sys.exit(0 if generate_image(args.prompt, args.output, args.steps) else 1)


if __name__ == "__main__":
    main()
